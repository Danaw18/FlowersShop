module com.example.flowers2 {requires java.sql;
    requires javafx.controls;
    requires javafx.fxml;

    opens com.example.flowers2 to javafx.fxml;
    exports com.example.flowers2;
}