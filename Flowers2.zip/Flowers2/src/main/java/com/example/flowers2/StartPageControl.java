package com.example.flowers2;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class StartPageControl {
    @FXML
    private Button login1;

    @FXML
    private Button login11;

    @FXML
    void actionAdmin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminLoginPage.fxml"));
        Stage window = (Stage) login1.getScene().getWindow();
        window.setScene(new Scene(root,700,450));
    }

    @FXML
    void actionUser(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
        Stage window = (Stage) login11.getScene().getWindow();
        window.setScene(new Scene(root,700,450));
    }

}





