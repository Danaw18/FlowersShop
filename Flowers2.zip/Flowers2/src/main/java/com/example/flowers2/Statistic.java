package com.example.flowers2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class Statistic {

    @FXML
    private Label InformationAboutUsers;

    @FXML
    private Button news;


    @FXML
    void news(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("StartPage.fxml"));
        Stage window = (Stage) news.getScene().getWindow();
        window.setScene(new Scene(root,700,450));
    }

    @FXML
    void see(ActionEvent event) throws FileNotFoundException, SQLException {
        // CountLines();
        Connection connection = DataBase.createDataBase();
        Statement statement = connection.createStatement();
        ResultSet set = statement.executeQuery("select user_id\n" +
                "from users\n" +
                "order by user_id DESC\n" +
                "LIMIT 1;");
        while (set.next()){
            String inf = set.getString("user_id");
            InformationAboutUsers.setText(inf + " people registered on this site!!!");
        }

    }
}

