package com.example.flowers2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class SignUpControl {
    @FXML
    private Button LogInButton;

    @FXML
    private Button SignUpp;

    @FXML
    private TextField email;

    @FXML
    private TextField password;

    @FXML
    private TextField username;

    @FXML
    void LoginAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
        Stage window = (Stage) LogInButton.getScene().getWindow();
        window.setScene(new Scene(root, 700, 450));
    }

    @FXML
    void SignUpButtonAction(ActionEvent event) throws IOException {         // Registration
        try{
            if(username.getText().isEmpty()) {
                throw new Exception("Username Field is empty");
            }
            if( password.getText().isEmpty()){
                throw new Exception("Password Field is empty");
            }
            if(email.getText().isEmpty()){
                throw new Exception("Email Field is empty");
            }
            CheckData();

        }catch (Exception e){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Warning");
            alert.setHeight(250);
            alert.setWidth(250);
            alert.setContentText(String.valueOf(e));
            alert.showAndWait();
        }
    }

    void CheckData() throws Exception {
        if(!username.getText().matches("^[a-zA-Z]+$")){
            throw new Exception("The username must contain only words!");
        }
        if(username.getText().equals(password.getText())){           // void logic();
            throw new Exception("Password Matched");
        }
        if (username.getText().length() < 4 || username.getText().length() > 9) {
            throw new Exception("The username length should be from 4 to 9.");
        }
        if (password.getText().length() < 4 || password.getText().length() > 9) {
            throw new Exception("The password length should be from 4 to 9.");
        }
        if (email.getText().length() < 4 ||email.getText().length() > 9 ) {
            throw new Exception("The email length should be from 4 to 9");
        }

        addData();
        Parent root = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
        Stage window = (Stage) LogInButton.getScene().getWindow();
        window.setScene(new Scene(root,700,450));
    }

    void addData() {

        try {
            Connection connection = DataBase.createDataBase();
            String usernameString = username.getText().trim();
            String passwordString = password.getText().trim();
            String emailString = email.getText().trim();

            String query = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
            PreparedStatement statement1 = connection.prepareStatement(query);
            statement1.setString(1, usernameString);
            statement1.setString(2, passwordString);
            statement1.setString(3, emailString);

            statement1.execute();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}


