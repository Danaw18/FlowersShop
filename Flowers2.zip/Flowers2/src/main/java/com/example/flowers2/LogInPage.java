package com.example.flowers2;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class LogInPage implements Initializable {
    @FXML
    private Button Forgot_button;

    @FXML
    private Text SignIn;

    @FXML
    private Button login;

    @FXML
    private Button sign_up_button;

    @FXML
    private TextField txtShowPassword;
    String password;

    @FXML
    private ImageView lblClose;

    @FXML
    private ImageView lblOpen;
    @FXML
    private PasswordField txtHidePassword;

    @FXML
    private TextField username;

    @FXML
    void HidePasswordOnAction(KeyEvent event) {
        password = txtHidePassword.getText();
        txtShowPassword.setText(password);
    }

    @FXML
    void ShowPasswordOnAction(KeyEvent event) {
        password = txtShowPassword.getText();
        txtHidePassword.setText(password);

    }

    @FXML
    void ForgotPass(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ForgotPass.fxml"));
        Stage window = (Stage) Forgot_button.getScene().getWindow();
        window.setScene(new Scene(root,700,450));
    }

    boolean checkData() throws SQLException, IOException {
        Connection connection = DataBase.createDataBase();
        Statement statement = connection.createStatement();
        ResultSet set = statement.executeQuery("select * from users;");
        while (set.next()){
            String usernameStr = username.getText().trim();
            String passwordStr = txtShowPassword.getText().trim();
            if(usernameStr.equals(set.getString("username"))
            && passwordStr.equals(set.getString("password")))
                return true;
        }
        return false;
    }

    @FXML
    void loginAction(ActionEvent event) throws IOException {
        try {
            ifEmpty();
            checkPass();
            if(checkData()){
                Parent root = FXMLLoader.load(getClass().getResource("FlowerBase.fxml"));
                Stage window = (Stage) SignIn.getScene().getWindow();
                window.setScene(new Scene(root, 900, 700));
            }
        } catch (Exception e) {
        }}

    void ifEmpty () throws IOException {
        try {
            if (username.getText().isEmpty()) {
                throw new Exception("Field is empty");
            }
            if (txtShowPassword.getText().isEmpty()) {
                throw new Exception("Field is empty");
            }
        } catch (Exception ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Warning");
            alert.setHeight(250);
            alert.setWidth(250);
            alert.setContentText(String.valueOf(ex));
            alert.showAndWait();
            Parent root = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
            Stage window = (Stage) SignIn.getScene().getWindow();
            window.setScene(new Scene(root, 700,450));

        }
    }
    void checkPass () throws Exception {
        try { Connection connection = DataBase.createDataBase();
        Statement statement = connection.createStatement();
        ResultSet set = statement.executeQuery("select * from users;");
        while (set.next()) {
            String usernameStr = username.getText().trim();
            String passwordStr = txtShowPassword.getText().trim();
            if (usernameStr.equals(set.getString("username"))
                    && !passwordStr.equals(set.getString("password")))
                throw new IOException("Password incorrect");
        }
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Message");
            alert.setHeight(250);
            alert.setWidth(250);
            alert.setContentText(String.valueOf(e));
            alert.showAndWait();
            Parent root = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
            Stage window = (Stage) SignIn.getScene().getWindow();
            window.setScene(new Scene(root, 700, 450));
        }
    }

    @FXML
    void userSignUp(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
        Stage window = (Stage) sign_up_button.getScene().getWindow();
        window.setScene(new Scene(root, 700, 450));
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        txtShowPassword.setVisible(false);
        lblOpen.setVisible(false);
    }

    public void Open_eye_clic(MouseEvent mouseEvent) {
        txtShowPassword.setVisible(false);
        lblOpen.setVisible(false);
        lblClose.setVisible(true);
        txtHidePassword.setVisible(true);
    }

    public void Close_eye_clic(MouseEvent mouseEvent) {
        txtShowPassword.setVisible(true);
        lblOpen.setVisible(true);
        lblClose.setVisible(false);
        txtHidePassword.setVisible(false);
    }
}

