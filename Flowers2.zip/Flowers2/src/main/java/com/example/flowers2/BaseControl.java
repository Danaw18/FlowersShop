package com.example.flowers2;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class BaseControl {
    @FXML
    private Button pay;
    @FXML
    private Label textField1;
    @FXML
    private Label textField2;
    @FXML
    private CheckBox addCustomVaseCheckbox;
    @FXML
    private CheckBox addFragranceCheckbox;
    @FXML
    private CheckBox addRibbonCheckbox;
    @FXML
    private Button buttontoPayment;
    @FXML
    private BorderPane pane;
    @FXML
    private CheckBox withNote;
    @FXML
    private Label textField3;
    @FXML
    private Label costOfTotalLabel;
    @FXML
    private Label totalLabel;
    @FXML
    private Label message;

    @FXML
    private Label messageText;
    private FlowerArrangementFactory currentFactory;

  @FXML
  void Sorry1(ActionEvent event) {
      currentFactory = new SorryArrangementFactory();
      FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
      String arrangementName = arrangement.getName();
      textField1.setText( arrangementName + ", Price: " + 23000);
  }
  @FXML  void Sorry2(ActionEvent event) {
      currentFactory = new SorryArrangementFactory();
      FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
       String arrangementName = arrangement.getName();
      textField1.setText( arrangementName + ", Price: " + 27000);}
      @FXML
      void Sorry3 (ActionEvent event){
          currentFactory = new SorryArrangementFactory();
          FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
          String arrangementName = arrangement.getName();
          textField1.setText(arrangementName + ", Price: " + 31000);
      }
      @FXML
      void Teacher1 (ActionEvent event){
          currentFactory = new TeacherArrangementFactory();
          FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
          String arrangementName = arrangement.getName();
          textField1.setText( arrangementName + ", Price: " + 18000);
      }
      @FXML
      void Teacher2 (ActionEvent event){
          currentFactory = new TeacherArrangementFactory();
          FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
          String arrangementName = arrangement.getName();
          textField1.setText( arrangementName + ", Price: " + 21000);
      }
      @FXML
      void
      Teacher3(ActionEvent event) {
          currentFactory = new TeacherArrangementFactory();
          FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
          String arrangementName = arrangement.getName();
          textField1.setText( arrangementName + ", Price: " + 24000);
      }
      @FXML
      void birthday1 (ActionEvent event){
          currentFactory = new BirthdayArrangementFactory();
          FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
          String arrangementName = arrangement.getName();
          textField1.setText( arrangementName + ", Price: " + 30000);
      }
      @FXML
      void birthday2 (ActionEvent event){
          currentFactory = new BirthdayArrangementFactory();
          FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
          String arrangementName = arrangement.getName();
          textField1.setText( arrangementName + ", Price: " + 45000);
      }
      @FXML
      void birthday3 (ActionEvent event){
          currentFactory = new BirthdayArrangementFactory();
          FlowerArrangement arrangement = currentFactory.createFlowerArrangement();
          String arrangementName = arrangement.getName();
          textField1.setText(arrangementName + ", Price: " + 23000);
      }

      @FXML
      void buttontoPayment (ActionEvent event) throws IOException {
            costOfTotalLabel.setVisible(true);
            totalLabel.setVisible(true);

            String[] a1 = textField1.getText().split(" ");
            String[] a2 = textField2.getText().split(" ");
            String[] a3 = textField3.getText().split(" ");


            long sum = 0;
            sum += Integer.parseInt(String.valueOf(a1[a1.length - 1]));
            sum += Integer.parseInt(String.valueOf(a2[a2.length - 1]));
            sum += Integer.parseInt(String.valueOf(a3[a3.length - 1]));

            costOfTotalLabel.setText(sum + "");

      }
    private Decora flowerArrangement;

    @FXML
    void initialize() {
        flowerArrangement = new BasicFlowerArrangement();
    }
    @FXML
    void addCustomVaseCheckbox(ActionEvent event) {
      if(addCustomVaseCheckbox.isSelected()){
          flowerArrangement = new CustomVaseDecorator(flowerArrangement);
          int price = (int) flowerArrangement.getPrice();
      textField2.setText("Custom Vase, "+"Price: "+price);
      addRibbonCheckbox.setSelected(false);
    }}


    @FXML
    void addFragranceCheckbox(ActionEvent event) {
       if(addFragranceCheckbox.isSelected()){
           flowerArrangement = new FragranceDecorator(flowerArrangement);
           int price = (int)flowerArrangement.getPrice();
      textField3.setText("Fragrance, "+"Price: "+price);
      withNote.setSelected(false);
      }
    }

    @FXML
    void addRibbonCheckbox(ActionEvent event) {
      if(addRibbonCheckbox.isSelected()){
          flowerArrangement = new RibbonDecorator(flowerArrangement);
          int price = (int)flowerArrangement.getPrice();
      textField2.setText("Ribbon, "+"Price: " + price);
      addCustomVaseCheckbox.setSelected(false);
      }
    }
      @FXML
      void withNote (ActionEvent event){
      if(withNote.isSelected()){
          flowerArrangement = new NoteDecorator(flowerArrangement);
          int price = (int)flowerArrangement.getPrice();
      textField3.setText("Note, "+"Price: " + price);
      addFragranceCheckbox.setSelected(false);
      }}





    @FXML
    protected void pay(ActionEvent actionEvent) {

        Customer customer=new Customer("Customer",messageText);
        pane.setVisible(true);
        message.setVisible(true);
        messageText.setVisible(true);

        customer.update();
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                pane.setVisible(false);
                message.setVisible(false);
                messageText.setVisible(false);
            }
        },3000);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.exit();
                System.exit(0);
            }
        },9000);





    }
    }



