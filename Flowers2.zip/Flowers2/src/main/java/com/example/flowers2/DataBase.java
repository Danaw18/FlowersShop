package com.example.flowers2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBase {
    public static Connection connection = null;
    public static synchronized Connection createDataBase() {
        if(connection == null) {
            try {
                connection = DriverManager.getConnection("jdbc:postgresql://localhost:5433/pattern_project", "postgres", "iceayauka@04");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        return connection;
    }
}
