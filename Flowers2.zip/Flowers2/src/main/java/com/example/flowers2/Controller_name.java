package com.example.flowers2;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import javafx.event.ActionEvent;


class PurchaseSubject {
    private List<PurchaseObserver> observers = new ArrayList<>();

    public void addPurchaseObserver(PurchaseObserver observer) {
        observers.add(observer);
    }

    public void purchaseMade() {
        notifyObservers();
    }

    private void notifyObservers() {
        for (PurchaseObserver observer : observers) {
            observer.update();
        }
    }
}


interface PurchaseObserver {
    void update();
}

class Customer implements PurchaseObserver {
    private String name;
    private Label label;

    public Customer(String name,Label label) {
        this.name = name;
        this.label = label;
    }

    @Override
    public void update() {
        String message = "Thanks for your purchase, " + name + "! \nWe have sale days on 31.12.2023.";
        label.setText(message);
    }
}

public class Controller_name {
    private PurchaseSubject purchaseSubject;


    public Controller_name(PurchaseSubject purchaseSubject) {
        this.purchaseSubject = purchaseSubject;
    }

    public void buttonOnAction(ActionEvent actionEvent) {
        purchaseSubject.purchaseMade();
    }
}


