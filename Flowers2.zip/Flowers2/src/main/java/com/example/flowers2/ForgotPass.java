package com.example.flowers2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ForgotPass {
    @FXML
    private Button back;

    @FXML
    private Button change;

    @FXML
    private TextField newPass;
    @FXML
    private TextField username;
    @FXML
    private TextField email;
    String name;
    String pass;
    String em;
    @FXML
    void back(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
        Stage window = (Stage) back.getScene().getWindow();
        window.setScene(new Scene(root,700 ,450));
    }

    void checkFields() throws IOException ,NullPointerException{
        name = username.getText();
        pass = newPass.getText();
        em = email.getText();
        try{
            if (name.length() < 4 || name.length() > 9) {
                throw new Exception("The username length should be from 4 to 9.");
            }
            if (pass.length() < 4 || pass.length() > 9) {
                throw new Exception("The password length should be from 4 to 9.");
            }

            IfUserNotFound();
        }catch (Exception ex){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Warning");
            alert.setHeight(250);
            alert.setWidth(250);
            alert.setContentText(String.valueOf(ex));
            alert.showAndWait();
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ForgotPass.fxml")));
            Stage window = (Stage) change.getScene().getWindow();
            window.setScene(new Scene(root,700,450));
        }
    }

    void IfUserNotFound() throws IOException,NullPointerException {
        ChangePass();
    }

    void ChangePass() throws IOException, NullPointerException {
        Connection connection = DataBase.createDataBase();
        String query = "update users set password = ? where username = ?;";
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, pass);
            preparedStatement.setString(2, name);
            preparedStatement.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        Parent root = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
        Stage window = (Stage) change.getScene().getWindow();
        window.setScene(new Scene(root,700,450));
    }

    @FXML
    void change(ActionEvent event) throws IOException,NullPointerException {
        try{
            if(username.getText().isEmpty()) {
                throw new Exception("Username Field is empty");
            }
            if( newPass.getText().isEmpty()){
                throw new Exception("Password Field is empty");
            }
            if(email.getText().isEmpty()){
                throw new Exception("Email Field is empty");
            }
        }catch (Exception ex){

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Warning");
            alert.setHeight(250);
            alert.setWidth(250);
            alert.setContentText(String.valueOf(ex));
            alert.showAndWait();
            Parent root = FXMLLoader.load(getClass().getResource("ForgotPass.fxml"));
            Stage window = (Stage) change.getScene().getWindow();
            window.setScene(new Scene(root,600,400));
        }
        checkFields();
    }}





