package com.example.flowers2;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminLogin {
    @FXML
    private TextField adminName;

    @FXML
    private TextField adminPass;

    @FXML
    private Button logButton;

    @FXML
    void LoginButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Sta.fxml"));
        Stage window = (Stage) logButton.getScene().getWindow();
        window.setScene(new Scene(root,700,450));
    }
}

