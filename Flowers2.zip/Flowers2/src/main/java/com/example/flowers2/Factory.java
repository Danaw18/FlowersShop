package com.example.flowers2;
 interface FlowerArrangementFactory {
    FlowerArrangement createFlowerArrangement();
}
 interface FlowerArrangement {
    String getName();
}
 class SorryArrangementFactory implements FlowerArrangementFactory {
    @Override
    public FlowerArrangement createFlowerArrangement() {
        return new SorryArrangement();
    }
}

 class TeacherArrangementFactory implements FlowerArrangementFactory {
    @Override
    public FlowerArrangement createFlowerArrangement() {
        return new TeacherArrangement();
    }
}

 class BirthdayArrangementFactory implements FlowerArrangementFactory {
    @Override      public FlowerArrangement createFlowerArrangement() {
        return new BirthdayArrangement();      }
}
class SorryArrangement implements FlowerArrangement {
    @Override      public String getName() {
        return "For Sorry Arrangement";
    }

}
class BirthdayArrangement implements FlowerArrangement {
    @Override
    public String getName() {
        return "Birthday Arrangement";
    }

}
class TeacherArrangement implements FlowerArrangement {
    @Override      public String getName() {
        return "Teacher Arrangement";
    }
}
