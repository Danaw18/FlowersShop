package com.example.flowers2;
interface Decora {
    String getDescription();

    double getPrice();
}
class BasicFlowerArrangement implements Decora {
    @Override
    public String getDescription() {
        return "";
    }

    @Override
    public double getPrice() {
        return 0;
    }
}
abstract class FlowerArrangementDecorator implements Decora {
    protected Decora decoratedArrangement;

    public FlowerArrangementDecorator(Decora decoratedArrangement) {
        this.decoratedArrangement = decoratedArrangement;
    }

    @Override
    public String getDescription() {
        return decoratedArrangement.getDescription();
    }

    @Override
    public double getPrice() {
        return decoratedArrangement.getPrice();
    }
}
class CustomVaseDecorator extends FlowerArrangementDecorator {
    public CustomVaseDecorator(Decora decoratedArrangement) {
        super(decoratedArrangement);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "Custom Vase, Price: ";
    }

    @Override
    public double getPrice() {
        return  2000;
    }
}
class FragranceDecorator extends FlowerArrangementDecorator {
    public FragranceDecorator(Decora decoratedArrangement) {
        super(decoratedArrangement);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "Fragrance, Price: ";
    }

    @Override
    public double getPrice() {
        return  1000;
    }
}
class RibbonDecorator extends FlowerArrangementDecorator {
    public RibbonDecorator(Decora decoratedArrangement) {
        super(decoratedArrangement);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "Ribbon, Price: ";
    }

    @Override
    public double getPrice() {
        return 500;
    }
}
class NoteDecorator extends FlowerArrangementDecorator {
    public NoteDecorator(Decora decoratedArrangement) {
        super(decoratedArrangement);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "Note, Price: ";
    }

    @Override
    public double getPrice() {
        return 200;
    }
}
